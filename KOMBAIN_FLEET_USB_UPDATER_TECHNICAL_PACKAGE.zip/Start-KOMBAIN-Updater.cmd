@echo off
setlocal
cd /d "%~dp0"
set "LOGDIR=%LOCALAPPDATA%\KOMBAIN\Updater\Logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOGFILE=%LOGDIR%\launcher.log"
echo [%date% %time%] Starting KOMBAIN Updater>>"%LOGFILE%"
dotnet "KOMBAIN USB Fleet Updater.dll" >>"%LOGFILE%" 2>&1
if errorlevel 1 (
  echo.>>"%LOGFILE%"
  echo The application did not start successfully.
  echo Diagnostic log: "%LOGFILE%"
  echo.
  type "%LOGFILE%"
  pause
)
endlocal
