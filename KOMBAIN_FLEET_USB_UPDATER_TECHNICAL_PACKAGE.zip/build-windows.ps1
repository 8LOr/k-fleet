param(
    [string]$Configuration = "Release",
    [string]$Runtime = "win-x64",
    [string]$AndroidSdk = "$env:LOCALAPPDATA\Android\Sdk",
    [switch]$SelfContained
)

$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
$project = Join-Path $projectRoot "src\Kombain.Updater\Kombain.Updater.csproj"
$output = Join-Path $projectRoot "artifacts\KOMBAIN-Updater"

# The publish directory is generated output only. Recreate it on every build so
# bundled Android tools are never copied on top of stale files from a prior run.
if (Test-Path $output) {
    Remove-Item -LiteralPath $output -Recurse -Force
}

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw ".NET 8 SDK אינו מותקן"
}
$installedSdks = @(dotnet --list-sdks)
if (-not ($installedSdks | Where-Object { $_ -match '^8\.' })) {
    throw ".NET 8 SDK מלא אינו מותקן. יש להתקין SDK ולא רק Runtime."
}
if (-not (Test-Path (Join-Path $AndroidSdk "platform-tools\adb.exe"))) {
    throw "Android Platform Tools לא נמצאו ב-$AndroidSdk"
}

# ברירת המחדל היא framework-dependent כדי לאפשר בנייה אופליין ללא
# הורדת Microsoft.NET.ILLink.Tasks או runtime packs מ-NuGet.
$restoreArgs = @(
    "restore", $project,
    "--ignore-failed-sources"
)
$publishArgs = @(
    "publish", $project,
    "-c", $Configuration,
    "--no-restore",
    "-p:PublishTrimmed=false",
    "-p:PublishReadyToRun=false",
    "-p:PublishSingleFile=false",
    "-p:DebugType=None",
    "-o", $output
)

if ($SelfContained) {
    $restoreArgs += @("-r", $Runtime)
    $publishArgs += @("-r", $Runtime, "--self-contained", "true")
    Write-Host "בונה חבילה עצמאית. פעולה זו עשויה לדרוש אינטרנט או runtime packs שכבר נשמרו במחשב."
}
else {
    $publishArgs += @("--self-contained", "false")
    Write-Host "בונה חבילה אופליין התלויה ב-.NET 8 Desktop Runtime."
}

& dotnet @restoreArgs
if ($LASTEXITCODE -ne 0) {
    throw "שחזור רכיבי .NET נכשל. ודא שמותקן .NET 8 SDK מלא, כולל Windows Desktop targeting pack."
}

& dotnet @publishArgs
if ($LASTEXITCODE -ne 0) {
    throw "בניית הכלי נכשלה."
}

Copy-Item (Join-Path $projectRoot "Start-KOMBAIN-Updater.cmd") $output -Force

$platformTarget = Join-Path $output "tools\platform-tools"
$buildTarget = Join-Path $output "tools\build-tools"
New-Item -ItemType Directory -Force -Path $platformTarget, $buildTarget | Out-Null
Copy-Item (Join-Path $AndroidSdk "platform-tools\adb.exe") $platformTarget
Copy-Item (Join-Path $AndroidSdk "platform-tools\AdbWinApi.dll") $platformTarget
Copy-Item (Join-Path $AndroidSdk "platform-tools\AdbWinUsbApi.dll") $platformTarget

$latestBuildTools = Get-ChildItem (Join-Path $AndroidSdk "build-tools") -Directory | Sort-Object Name -Descending | Select-Object -First 1
if (-not $latestBuildTools) { throw "Android Build Tools לא נמצאו" }
Copy-Item (Join-Path $latestBuildTools.FullName "aapt2.exe") $buildTarget
Copy-Item (Join-Path $latestBuildTools.FullName "apksigner.bat") $buildTarget
Copy-Item (Join-Path $latestBuildTools.FullName "lib") $buildTarget -Recurse -Force

$zip = Join-Path $projectRoot "artifacts\KOMBAIN-Updater-win-x64.zip"
if (Test-Path $zip) { Remove-Item $zip }
Compress-Archive -Path (Join-Path $output "*") -DestinationPath $zip
Write-Host "נוצרה חבילה: $zip"
if (-not $SelfContained) {
    Write-Host "להפעלת החבילה נדרש .NET 8 Desktop Runtime בעמדת Windows."
}
