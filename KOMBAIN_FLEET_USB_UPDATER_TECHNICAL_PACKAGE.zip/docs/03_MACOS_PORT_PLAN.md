# macOS — תוכנית התאמה וקומפילציה

## יעד קבלה מחייב — לפי מחשב הממשיך

**macOS Ventura 13.7.8 על Mac עם מעבד Intel ‏64-bit. חבילת היעד הראשית: `osx-x64`.** זו דרישת מוצר מאושרת, ולא טענה שתאימות כבר נבדקה.

- מסירת גרסה שמחייבת macOS 14 ומעלה אינה עומדת בדרישה.
- תוצר arm64 בלבד אינו עומד בדרישה. אין תלות ב־Apple Silicon או ב־Rosetta במחשב היעד; האפליקציה וכל התלויות החיצוניות חייבות לפעול בו כ־x64, או להיות universal עם רכיב x64.
- Apple Silicon ‏`osx-arm64` הוא יעד נוסף אופציונלי. אינו מחליף בדיקה על Intel ו־13.7.8.
- יש לבחור ולנעול גרסאות SDK/runtime, UI framework, Java ו־Android Platform/Build Tools התואמות למערכת זו. אין להניח שהגרסה החדשה ביותר מתאימה ל־Ventura.
- יש להפריד בין יכולת ריצה שנבדקה לבין תמיכה רשמית של ספקי התלויות: תיעוד Avalonia העדכני מסווג macOS 13 ומטה כ־Tier 3. לכן התמיכה בדרישת המוצר חייבת להישען על גרסאות נבחרות וראיות בדיקה; אין להציג אותה כהבטחת תמיכה של Avalonia או Microsoft.
- אם אין שילוב תלויות בר־תחזוקה שעומד ביעד, יש לדווח על החסם ולהציע חלופה לפני שינוי דרישת מערכת ההפעלה. אין להעלות את המינימום בשקט.

## מצב נוכחי

ה־csproj משתמש ב־UseWPF=true וב־net8.0-windows, והמסכים תלויים ב־System.Windows, Microsoft.Win32.OpenFileDialog ו־WPF XAML. `dotnet publish -r osx-arm64` על הפרויקט הזה אינו יוצר כלי GUI מקומי למק. Cross-build של תוצר Windows על Mac אינו גרסת macOS.

דרישת המוצר היא להשאיר כלי תפעול אופליין דרך USB, ממשק עברי RTL, בדיקות APK, סימולציה, פיילוט, עדכון ללא uninstall ויומן. אין צורך לשנות את אפליקציית Android כדי ליצור את ממשק המק.

## מסלול מוצע

לשמר לוגיקת C# ולבודד מנוע שאינו תלוי ב־WPF. אפשר לבנות ממשק משותף ב־Avalonia, שתומכת ב־Windows וב־macOS (Apple Silicon ו־Intel), ולא להעתיק ישירות XAML של WPF. זו הצעה הנדסית, לא migration שכבר בוצעה. יש לבחור גרסה יציבה ולנעול SDK וחבילות לפי התאימות שלה. [תיעוד Avalonia רשמי](https://docs.avaloniaui.net/docs/supported-platforms).

```text
src/
  Kombain.Updater.Core/       models, inspection, fleet, deployment engine
  Kombain.Updater.Platform/   tool paths, process runner, filesystem/logs
  Kombain.Updater.Desktop/    cross-platform UI + ViewModels
tests/                       process fixtures and domain/engine tests
scripts/
  build-windows.ps1
  build-macos.sh
```

השמות והמבנה מוצעים; אינם קבצים קיימים בחבילה. קודם להפריד orchestration מ־MainWindow ולהבטיח ש־Windows ממשיך לפעול, ורק אז לממש UI נוסף/משותף.

## מה משתף ומה משתנה

| אזור | מצב/פעולת port |
|---|---|
| מודלי APK/CSV ו־SHA-256 | ניתנים לשיתוף לאחר הוצאת תלות ב־UI |
| AdbService | רוב הפקודות משותפות; בדוק פלט, UTF-8, temp והנחות splits |
| DeployOne והאישורים | חילוץ למנוע עם תוצאות מובנות; UI מיישם אישורים |
| ProcessRunner | Java/ADB ישירים עם ArgumentList; בלי cmd.exe/BAT; timeout ו־process kill |
| JavaToolLocator | כיום non-Windows מחזיר java בלבד; נדרש JAVA_HOME ובדיקה באמצעות java -version, איתור JDK macOS |
| AndroidToolLocator | הוסף SDK ברירת מחדל של Mac והתאמה ל־.app bundle; לא להשתמש ב־.exe/DLLs |
| CSV | שמור UTF-8/BOM; fallback מלא/מפורש במקום מיפוי חלקי לפי הצורך |
| Logs | ספק נתיב writable ומוצג במק, למשל Library/Application Support; בדוק actual path |
| GUI | חלונות, file picker, טבלה, progress, theme ו־RTL חדשים/מותאמים |
| Packaging | .app, Info.plist, arm64/x64, executable permissions ו־native dependencies |

## כלים במק

מפתח צריך .NET SDK בגרסה שנבחרה, Android SDK Platform Tools/Build Tools ו־Java תואם. SDK נמצא לעיתים ב־`~/Library/Android/sdk`; AndroidToolLocator הנוכחי אינו מנסה נתיב זה כברירת מחדל ולכן נדרש נתיב מפורש או משתנה ANDROID_HOME.

אפשר להתחיל בפיילוט מק עם תלויות חיצוניות מותקנות ו־Tool Paths מפורשים. בהמשך לארוז Android tools למק במקום הכלים של Windows. Java אינה מתווספת אוטומטית לחבילה. אם מבקשים לכלול JRE, יש להגדיר מקור, ארכיטקטורה, רישוי ורכיבי חבילה בפירוש.

סדר איתור מוצע: הגדרה מפורשת → כלי חבילה → SDK/Java home → PATH שנבדק. תהליך שהופעל דרך Finder לא בהכרח מקבל PATH של shell; אין להסתמך על Homebrew או ~/.zshrc ללא בדיקה.

אין דרישה לשנות Device Owner או לפרמט טאבלט. גם במק נדרש אישור RSA וחיבור USB debugging שמותר לפי מדיניות הצי.

## תוכנית ביצוע ושערי קבלה

1. **ליבת C# עצמאית:** בדיקות תוצאות/כישלונות של inspection, CSV, signature ו־version; process runner ניתן להחלפה בבדיקות. Windows pilot נשמר.
2. **CLI אבחוני במק:** סריקה, קריאת מידע ו־verify APK בלבד; אין install אוטומטי בבדיקת smoke.
3. **ממשק מק:** טבלה RTL ושמות בעברית, בחירה, file picker וסימולציה; plan קפוא ונעילת controls בזמן פעולה.
4. **הקשחת פעולות:** timeouts, cancellation שהורגת child processes, hash מחדש לפני install, version preflight, serialize logs ומצב audit-failed נפרד.
5. **פיילוט יחיד:** שני אישורים, digest תואם, install -r, versionCode, בדיקת דוחות ידנית. Windows ו־Mac משתמשים באותו מנוע ללא עקיפות אבטחה.
6. **אריזה:** חבילת `.app` ראשית עבור `osx-x64`, הנפתחת מ־Finder על macOS 13.7.8 במחשב Intel, ללא terminal. כל התלויות המוצהרות והיומן נבדקים שם. arm64 הוא תוצר נוסף אופציונלי.
7. **צי:** הרחבת כמות רק לאחר בדיקות 1/2/4/8 עם מכשירים אמיתיים ו־USB hub מוזן. אין להפעיל מקביליות רק מפני שהסמפור הוא 6.

## קומפילציה עתידית

הפקודות הבאות הן דוגמאות לאחר יצירת Desktop project רב־פלטפורמי; אין להריצן כאילו הפרויקט הזה כבר קיים:

```sh
dotnet restore src/Kombain.Updater.Desktop/Kombain.Updater.Desktop.csproj
dotnet publish src/Kombain.Updater.Desktop/Kombain.Updater.Desktop.csproj -c Release -r osx-x64 --self-contained true
```

ל־Apple Silicon, רק אם נדרש יעד נוסף, מפרסמים בנפרד עם `-r osx-arm64`. SelfContained אורז runtime אך אינו מבטל דרישות OS של runtime, UI, Java או Android tools; אין לראות בו פתרון אוטומטי לתאימות Ventura.

publish אינו יוצר אוטומטית חבילת .app תקינה. הוסף מבנה bundle, Info.plist, אייקון וקובצי כלים לפי מדריך הפריסה; בדוק את דרישות signing/notarization לשיטת ההפצה שנבחרה. [מדריך macOS של Avalonia](https://docs.avaloniaui.net/docs/deployment/macos).

חתימת אפליקציית המק (codesign) וחתימת APK Android הן מערכות נפרדות. כלי מק מחזיק APK חתום ובודק אותו; אין להעביר אליו את keystore לצורך הפצת עדכונים. keystore נדרש למחשב/תהליך הבנייה של KOMBAIN, לא לעמדת ה־updater.

## הגדרת הצלחה

יש לשמור ראיות מהמחשב המדויק של הממשיך או ממחשב Intel שקול עם 13.7.8: גרסת macOS, ארכיטקטורה, גרסאות/hash של רכיבי החבילה והתלויות, ו־commit/hash של הכלי. בדיקת build מוצלחת על Mac חדש אינה מספיקה.

שערי הקבלה על **Intel / macOS 13.7.8**:

1. בנייה מהמקור במחשב הממשיך עם SDK ותלויות מתועדים, או תיעוד חסם ברור אם לבנייה נדרשת עמדה נפרדת. הפעלה על 13.7.8 מחייבת בכל מקרה.
2. פתיחת `.app` מ־Finder, בלי להסתמך על PATH של Terminal ובלי שדרוג macOS.
3. הפעלת ADB, aapt2 ו־Java/apksigner.jar בארכיטקטורות התואמות ל־Intel; סריקת טאבלט פיזי וקריאת מידע.
4. בחירת APK ו־CSV בנתיב עברי/עם רווחים, תצוגת RTL, בדיקת חתימה וסימולציה עם יומן נגיש.
5. פיילוט מכשיר יחיד עם אישור כפול, התאמת חתימה, אימות versionCode ובדיקת הדוחות וההגדרות לאחר העדכון.
6. בדיקת כשל: unauthorized, ניתוק USB ואימות חתימה שנכשל, ללא uninstall או אובדן נתונים יזום.

גרסת המק מתקבלת רק אחרי פתיחה מ־Finder במחשב היעד, גילוי טאבלט, UTF-8/עברית, אימות APK, סימולציה עם יומן ופיילוט שמירת נתונים. בדיקה על macOS אינה מחליפה regression ב־Windows. שימוש ברשת להכנת תלויות/חתימת חבילה מתועד בנפרד; עמדת תפעול הטאבלטים פועלת אופליין.
