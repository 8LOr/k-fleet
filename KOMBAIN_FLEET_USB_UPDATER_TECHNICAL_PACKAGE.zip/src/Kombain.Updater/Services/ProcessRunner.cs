using System.Diagnostics;
using System.IO;

namespace Kombain.Updater.Services;

public sealed record ProcessResult(int ExitCode, string Output, string Error);

public sealed class ProcessRunner
{
    public async Task<ProcessResult> RunAsync(string executable, IReadOnlyList<string> arguments, CancellationToken token = default)
    {
        ProcessStartInfo info;
        if (OperatingSystem.IsWindows() && executable.EndsWith(".bat", StringComparison.OrdinalIgnoreCase))
        {
            var commandInterpreter = Environment.GetEnvironmentVariable("ComSpec") ?? "cmd.exe";
            info = new ProcessStartInfo(commandInterpreter) { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
            ConfigureJavaForAndroidTools(info);
            info.ArgumentList.Add("/d");
            info.ArgumentList.Add("/c");
            // CALL keeps quoted .bat paths intact when the application directory contains spaces.
            info.ArgumentList.Add("call " + QuoteForCmd(executable, arguments));
        }
        else
        {
            info = new ProcessStartInfo(executable) { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
            foreach (var argument in arguments) info.ArgumentList.Add(argument);
        }
        using var process = new Process { StartInfo = info };
        process.Start();
        var output = process.StandardOutput.ReadToEndAsync(token);
        var error = process.StandardError.ReadToEndAsync(token);
        await process.WaitForExitAsync(token);
        return new ProcessResult(process.ExitCode, await output, await error);
    }

    private static string QuoteForCmd(string executable, IReadOnlyList<string> arguments)
    {
        static string Quote(string value) => "\"" + value.Replace("\"", "\"\"").Replace("%", "%%") + "\"";
        return Quote(executable) + " " + string.Join(" ", arguments.Select(Quote));
    }

    private static void ConfigureJavaForAndroidTools(ProcessStartInfo info)
    {
        var configured = Environment.GetEnvironmentVariable("JAVA_HOME");
        if (!string.IsNullOrWhiteSpace(configured) && File.Exists(Path.Combine(configured, "bin", "java.exe"))) return;

        var candidates = new List<string>();
        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        candidates.Add(Path.Combine(programFiles, "Android", "Android Studio", "jbr"));

        foreach (var parent in new[] { Path.Combine(programFiles, "Eclipse Adoptium"), Path.Combine(programFiles, "Java") })
        {
            if (Directory.Exists(parent)) candidates.AddRange(Directory.GetDirectories(parent).OrderByDescending(x => x));
        }

        var javaHome = candidates.FirstOrDefault(x => File.Exists(Path.Combine(x, "bin", "java.exe")));
        if (javaHome is null) return;
        info.Environment["JAVA_HOME"] = javaHome;
        info.Environment["PATH"] = Path.Combine(javaHome, "bin") + ";" + (info.Environment["PATH"] ?? "");
    }
}
