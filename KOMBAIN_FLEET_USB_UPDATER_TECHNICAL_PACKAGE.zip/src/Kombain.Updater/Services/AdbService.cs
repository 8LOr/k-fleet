using System.IO;
using System.Text.RegularExpressions;
using Kombain.Updater.Models;

namespace Kombain.Updater.Services;

public sealed class AdbService(ProcessRunner runner)
{
    public const string KombainPackage = "mil.egoz.kombain";

    public async Task<IReadOnlyList<TabletDevice>> DiscoverAsync(CancellationToken token = default)
    {
        var result = await runner.RunAsync(AndroidToolLocator.Find("adb"), ["devices", "-l"], token);
        if (result.ExitCode != 0) throw new InvalidOperationException($"ADB אינו זמין: {result.Error.Trim()}");
        var devices = new List<TabletDevice>();
        foreach (var line in result.Output.Split('\n', StringSplitOptions.RemoveEmptyEntries).Skip(1))
        {
            var parts = Regex.Split(line.Trim(), @"\s+");
            if (parts.Length < 2) continue;
            var serial = parts[0];
            var state = parts[1];
            var model = parts.FirstOrDefault(x => x.StartsWith("model:"))?.Split(':', 2)[1].Replace('_', ' ') ?? "—";
            devices.Add(new TabletDevice { Serial = serial, AdbState = state, Model = model, Selected = state == "device", Status = StateText(state) });
        }
        await Task.WhenAll(devices.Where(d => d.AdbState == "device").Select(d => PopulateAsync(d, token)));
        return devices;
    }

    public async Task<ProcessResult> InstallUpdateAsync(TabletDevice device, string apkPath, CancellationToken token)
        => await runner.RunAsync(AndroidToolLocator.Find("adb"), ["-s", device.Serial, "install", "-r", "--no-streaming", apkPath], token);

    public async Task<(string VersionName, long VersionCode)> ReadInstalledVersionAsync(TabletDevice device, CancellationToken token)
    {
        var package = await ShellValue(device.Serial, ["dumpsys", "package", KombainPackage], token);
        var versionName = Regex.Match(package, @"versionName=([^\s]+)").Groups[1].Value;
        _ = long.TryParse(Regex.Match(package, @"versionCode=(\d+)").Groups[1].Value, out var versionCode);
        return (versionName, versionCode);
    }

    public async Task<string> ReadInstalledCertificateDigestAsync(TabletDevice device, CancellationToken token)
    {
        var packagePathOutput = await ShellValue(device.Serial, ["pm", "path", KombainPackage], token);
        var remotePath = packagePathOutput.Split('\n', StringSplitOptions.RemoveEmptyEntries)
            .Select(x => x.Trim()).FirstOrDefault(x => x.StartsWith("package:", StringComparison.Ordinal))?[8..];
        if (string.IsNullOrWhiteSpace(remotePath)) return "";
        var temporaryPath = Path.Combine(Path.GetTempPath(), $"kombain-installed-{Guid.NewGuid():N}.apk");
        try
        {
            var pull = await runner.RunAsync(AndroidToolLocator.Find("adb"), ["-s", device.Serial, "pull", remotePath, temporaryPath], token);
            if (pull.ExitCode != 0 || !File.Exists(temporaryPath)) return "";
            return await new CertificateService(runner).ReadApkCertificateDigestAsync(temporaryPath, token);
        }
        finally
        {
            if (File.Exists(temporaryPath)) File.Delete(temporaryPath);
        }
    }

    private async Task PopulateAsync(TabletDevice device, CancellationToken token)
    {
        device.AndroidVersion = await ShellValue(device.Serial, ["getprop", "ro.build.version.release"], token);
        var package = await ShellValue(device.Serial, ["dumpsys", "package", KombainPackage], token);
        device.AppVersion = Regex.Match(package, @"versionName=([^\s]+)").Groups[1].Value;
        if (string.IsNullOrWhiteSpace(device.AppVersion)) device.AppVersion = "לא מותקן";
        var battery = await ShellValue(device.Serial, ["dumpsys", "battery"], token);
        if (int.TryParse(Regex.Match(battery, @"level:\s*(\d+)").Groups[1].Value, out var level)) device.BatteryPercent = level;
        var storage = await ShellValue(device.Serial, ["df", "-k", "/data"], token);
        var last = storage.Split('\n', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "";
        var fields = Regex.Split(last.Trim(), @"\s+");
        if (fields.Length >= 4 && long.TryParse(fields[3], out var freeKb)) device.FreeStorageMb = freeKb / 1024;
        device.Status = "מוכן לעדכון";
    }

    private async Task<string> ShellValue(string serial, IReadOnlyList<string> shellArgs, CancellationToken token)
    {
        var args = new List<string> { "-s", serial, "shell" };
        args.AddRange(shellArgs);
        var result = await runner.RunAsync(AndroidToolLocator.Find("adb"), args, token);
        return result.ExitCode == 0 ? result.Output.Trim() : "";
    }

    private static string StateText(string state) => state switch
    {
        "device" => "מחובר",
        "unauthorized" => "יש לאשר את עמדת העדכונים בטאבלט",
        "offline" => "המכשיר אינו זמין",
        _ => $"מצב ADB: {state}"
    };
}
