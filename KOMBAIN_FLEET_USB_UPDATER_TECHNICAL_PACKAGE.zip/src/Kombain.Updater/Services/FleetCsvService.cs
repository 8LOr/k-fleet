using System.IO;
using System.Text;
using Kombain.Updater.Models;

namespace Kombain.Updater.Services;

public sealed class FleetCsvService
{
    public string DetectedEncoding { get; private set; } = "UTF-8";
    public string Warning { get; private set; } = "";

    public IReadOnlyDictionary<string, FleetRecord> Load(string path)
    {
        var text = ReadText(path);
        var lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        if (lines.Length == 0) throw new InvalidDataException("קובץ הצי ריק");
        var headers = ParseLine(lines[0]).Select(x => x.Trim().ToLowerInvariant()).ToArray();
        var serialIndex = Find(headers, "adb_serial", "serial", "מספר סידורי", "סיראל");
        var assetIndex = Find(headers, "asset_number", "asset", "מספר פנימי", "מספר נכס");
        var nameIndex = Find(headers, "display_name", "name", "שם", "שם תצוגה");
        if (serialIndex < 0 || assetIndex < 0)
        {
            if (lines[0].Contains("??", StringComparison.Ordinal))
                throw new InvalidDataException("הקובץ כבר מכיל סימני שאלה במקום עברית. המידע אבד בזמן השמירה; יש לשמור מחדש מ-Excel כסוג CSV UTF-8.");
            throw new InvalidDataException("נדרשות עמודות מספר סידורי ומספר פנימי");
        }
        var records = new Dictionary<string, FleetRecord>(StringComparer.OrdinalIgnoreCase);
        foreach (var line in lines.Skip(1).Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            var cells = ParseLine(line);
            if (cells.Count <= Math.Max(serialIndex, assetIndex)) continue;
            var serial = cells[serialIndex].Trim();
            if (serial.Length == 0) continue;
            var asset = cells[assetIndex].Trim();
            var name = nameIndex >= 0 && cells.Count > nameIndex ? cells[nameIndex].Trim() : $"טאבלט {asset}";
            records[serial] = new FleetRecord(serial, asset, name);
        }
        if (records.Values.Any(x => x.DisplayName.Contains("??", StringComparison.Ordinal)))
            Warning = "חלק מהשמות כבר נשמרו כסימני שאלה בקובץ המקור ולא ניתן לשחזר אותם אוטומטית";
        return records;
    }

    private string ReadText(string path)
    {
        var bytes = File.ReadAllBytes(path);
        if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF)
        {
            DetectedEncoding = "UTF-8 BOM";
            return Encoding.UTF8.GetString(bytes, 3, bytes.Length - 3);
        }
        if (bytes.Length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE)
        {
            DetectedEncoding = "UTF-16 LE";
            return Encoding.Unicode.GetString(bytes, 2, bytes.Length - 2);
        }
        if (bytes.Length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF)
        {
            DetectedEncoding = "UTF-16 BE";
            return Encoding.BigEndianUnicode.GetString(bytes, 2, bytes.Length - 2);
        }

        try
        {
            DetectedEncoding = "UTF-8";
            return new UTF8Encoding(false, true).GetString(bytes);
        }
        catch (DecoderFallbackException)
        {
            DetectedEncoding = "Windows-1255";
            return DecodeWindows1255(bytes);
        }
    }

    private static string DecodeWindows1255(byte[] bytes)
    {
        var result = new StringBuilder(bytes.Length);
        foreach (var value in bytes)
        {
            if (value < 0x80) result.Append((char)value);
            else if (value is >= 0xE0 and <= 0xFA) result.Append((char)('\u05D0' + value - 0xE0));
            else result.Append(value switch
            {
                0xA0 => '\u00A0', 0xAA => '\u00D7', 0xBA => '\u00F7',
                0xFD => '\u200E', 0xFE => '\u200F',
                0x91 => '\u2018', 0x92 => '\u2019', 0x93 => '\u201C', 0x94 => '\u201D',
                0x95 => '\u2022', 0x96 => '\u2013', 0x97 => '\u2014', 0x85 => '\u2026',
                _ => '\uFFFD'
            });
        }
        return result.ToString();
    }

    private static int Find(string[] headers, params string[] names) => Array.FindIndex(headers, h => names.Contains(h, StringComparer.OrdinalIgnoreCase));
    private static List<string> ParseLine(string line)
    {
        var result = new List<string>(); var value = new StringBuilder(); var quoted = false;
        for (var i = 0; i < line.Length; i++)
        {
            var c = line[i];
            if (c == '"' && quoted && i + 1 < line.Length && line[i + 1] == '"') { value.Append('"'); i++; }
            else if (c == '"') quoted = !quoted;
            else if (c == ',' && !quoted) { result.Add(value.ToString()); value.Clear(); }
            else value.Append(c);
        }
        result.Add(value.ToString());
        return result;
    }
}
