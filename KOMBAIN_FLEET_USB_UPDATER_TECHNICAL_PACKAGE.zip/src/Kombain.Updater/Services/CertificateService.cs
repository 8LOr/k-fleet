using System.IO;
using System.Text.RegularExpressions;

namespace Kombain.Updater.Services;

public sealed record CertificateInspection(string Digest, bool IsValid, string Error);

public sealed class CertificateService(ProcessRunner runner)
{
    public async Task<string> ReadApkCertificateDigestAsync(string apkPath, CancellationToken token = default)
        => (await InspectApkCertificateAsync(apkPath, token)).Digest;

    public async Task<CertificateInspection> InspectApkCertificateAsync(string apkPath, CancellationToken token = default)
    {
        try
        {
            var apksigner = AndroidToolLocator.Find("apksigner");
            string executable;
            IReadOnlyList<string> arguments;

            if (OperatingSystem.IsWindows() && apksigner.EndsWith(".bat", StringComparison.OrdinalIgnoreCase))
            {
                var jar = Path.Combine(Path.GetDirectoryName(apksigner) ?? "", "lib", "apksigner.jar");
                if (!File.Exists(jar))
                    return new("", false, $"apksigner.jar לא נמצא בתיקיית כלי Android: {jar}");

                var java = JavaToolLocator.Find();
                if (java is null)
                    return new("", false, "Java לא נמצאה. יש להתקין Android Studio או להגדיר JAVA_HOME לפני הפעלת הכלי");

                executable = java;
                arguments = ["-jar", jar, "verify", "--verbose", "--print-certs", apkPath];
            }
            else
            {
                executable = apksigner;
                arguments = ["verify", "--verbose", "--print-certs", apkPath];
            }

            var result = await runner.RunAsync(executable, arguments, token);
            var combined = (result.Output + Environment.NewLine + result.Error).Trim();
            if (result.ExitCode != 0)
                return new("", false, ShortError(combined, "apksigner נכשל ללא פירוט"));

            var match = Regex.Match(combined, @"certificate SHA-256 digest:\s*([0-9a-fA-F:]+)", RegexOptions.IgnoreCase);
            if (!match.Success)
                return new("", false, "apksigner פעל אך לא החזיר טביעת SHA-256 של תעודה");

            var digest = match.Groups[1].Value.Replace(":", "").ToUpperInvariant();
            return new(digest, true, "");
        }
        catch (Exception ex)
        {
            return new("", false, ShortError(ex.Message, "לא ניתן להפעיל את apksigner"));
        }
    }

    private static string ShortError(string value, string fallback)
    {
        if (string.IsNullOrWhiteSpace(value)) return fallback;
        var line = value.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault()?.Trim();
        return string.IsNullOrWhiteSpace(line) ? fallback : line;
    }
}
