using System.IO;

namespace Kombain.Updater.Services;

public static class JavaToolLocator
{
    public static string? Find()
    {
        if (!OperatingSystem.IsWindows()) return "java";

        var javaHome = Environment.GetEnvironmentVariable("JAVA_HOME");
        if (!string.IsNullOrWhiteSpace(javaHome))
        {
            var configured = Path.Combine(javaHome, "bin", "java.exe");
            if (File.Exists(configured)) return configured;
        }

        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var candidates = new List<string>
        {
            Path.Combine(programFiles, "Android", "Android Studio", "jbr"),
            Path.Combine(localAppData, "Programs", "Android Studio", "jbr")
        };

        AddInstallations(candidates, Path.Combine(programFiles, "Eclipse Adoptium"));
        AddInstallations(candidates, Path.Combine(programFiles, "Java"));

        return candidates
            .Select(x => Path.Combine(x, "bin", "java.exe"))
            .FirstOrDefault(File.Exists);
    }

    private static void AddInstallations(List<string> candidates, string parent)
    {
        try
        {
            if (Directory.Exists(parent)) candidates.AddRange(Directory.GetDirectories(parent).OrderByDescending(x => x));
        }
        catch
        {
            // A protected vendor directory should not prevent checking the other locations.
        }
    }
}
