using System.IO;

namespace Kombain.Updater.Services;

public static class AndroidToolLocator
{
    public static string Find(string tool)
    {
        var extension = OperatingSystem.IsWindows() ? ".exe" : "";
        var bundledRoot = Path.Combine(AppContext.BaseDirectory, "tools");
        var bundled = tool == "adb"
            ? Path.Combine(bundledRoot, "platform-tools", tool + extension)
            : Path.Combine(bundledRoot, "build-tools", tool + (tool == "apksigner" && OperatingSystem.IsWindows() ? ".bat" : extension));
        if (File.Exists(bundled)) return bundled;
        var sdk = Environment.GetEnvironmentVariable("ANDROID_HOME") ?? Environment.GetEnvironmentVariable("ANDROID_SDK_ROOT");
        if (string.IsNullOrWhiteSpace(sdk) && OperatingSystem.IsWindows())
            sdk = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Android", "Sdk");
        if (!string.IsNullOrWhiteSpace(sdk))
        {
            if (tool == "adb")
            {
                var adb = Path.Combine(sdk, "platform-tools", tool + extension);
                if (File.Exists(adb)) return adb;
            }
            var buildTools = Path.Combine(sdk, "build-tools");
            if (Directory.Exists(buildTools))
            {
                var candidate = Directory.GetDirectories(buildTools)
                    .OrderByDescending(x => x, StringComparer.OrdinalIgnoreCase)
                    .Select(x => Path.Combine(x, tool + (tool == "apksigner" && OperatingSystem.IsWindows() ? ".bat" : extension)))
                    .FirstOrDefault(File.Exists);
                if (candidate is not null) return candidate;
            }
        }
        return tool;
    }
}
