using System.IO;
using System.Security.Cryptography;
using Kombain.Updater.Models;

namespace Kombain.Updater.Services;

public sealed class ApkInspector(ProcessRunner runner)
{
    public async Task<ApkInspection> InspectAsync(string path, CancellationToken token = default)
    {
        await using var stream = File.OpenRead(path);
        var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, token));
        var info = new FileInfo(path);
        var badging = await runner.RunAsync(AndroidToolLocator.Find("aapt2"), ["dump", "badging", path], token);
        if (badging.ExitCode != 0)
            return new(path, hash, info.Length, "", "", 0, "", false, "לא ניתן לקרוא את פרטי ה־APK. יש להתקין Android Build Tools בעמדה.");
        var first = badging.Output.Split('\n').FirstOrDefault(x => x.StartsWith("package:")) ?? "";
        string Field(string name)
        {
            var marker = name + "='"; var start = first.IndexOf(marker, StringComparison.Ordinal);
            if (start < 0) return ""; start += marker.Length; var end = first.IndexOf('\'', start); return end < 0 ? "" : first[start..end];
        }
        var packageName = Field("name"); var versionName = Field("versionName");
        _ = long.TryParse(Field("versionCode"), out var versionCode);
        var certificate = await new CertificateService(runner).InspectApkCertificateAsync(path, token);
        var valid = packageName == AdbService.KombainPackage && certificate.IsValid;
        var message = packageName != AdbService.KombainPackage
            ? $"שם החבילה אינו תואם ל־KOMBAIN: {packageName}"
            : !certificate.IsValid
                ? $"לא ניתן לאמת את חתימת ה־APK: {certificate.Error}"
                : "הקובץ אומת ומוכן לבדיקת מכשירים";
        return new(path, hash, info.Length, packageName, versionName, versionCode, certificate.Digest, valid, message);
    }
}
