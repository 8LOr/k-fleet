using System.IO;
using System.Text.Json;
using Kombain.Updater.Models;

namespace Kombain.Updater.Services;

public sealed class AuditLogService
{
    private readonly string _directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KOMBAIN", "Updater", "Logs");

    public async Task AppendAsync(DeploymentLogEntry entry, CancellationToken token = default)
    {
        Directory.CreateDirectory(_directory);
        var path = Path.Combine(_directory, $"deployments-{entry.Timestamp:yyyy-MM}.jsonl");
        var json = JsonSerializer.Serialize(entry) + Environment.NewLine;
        await File.AppendAllTextAsync(path, json, token);
    }

    public string LogDirectory => _directory;
}
