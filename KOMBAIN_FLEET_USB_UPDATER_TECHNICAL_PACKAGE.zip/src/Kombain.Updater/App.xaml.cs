using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace Kombain.Updater;

public partial class App : Application
{
    private static readonly string LogDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "KOMBAIN", "Updater", "Logs");

    protected override void OnStartup(StartupEventArgs e)
    {
        DispatcherUnhandledException += OnDispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;

        try
        {
            base.OnStartup(e);
            var window = new MainWindow();
            MainWindow = window;
            window.Show();
        }
        catch (Exception ex)
        {
            ReportFatalError("startup", ex, true);
            Shutdown(-1);
        }
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        e.Handled = true;
        ReportFatalError("ui", e.Exception, true);
        Shutdown(-1);
    }

    private static void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception ex) ReportFatalError("runtime", ex, false);
    }

    private static void ReportFatalError(string stage, Exception exception, bool showDialog)
    {
        try
        {
            Directory.CreateDirectory(LogDirectory);
            var logPath = Path.Combine(LogDirectory, "startup-error.log");
            var details = new StringBuilder()
                .AppendLine($"[{DateTimeOffset.Now:O}] stage={stage}")
                .AppendLine(exception.ToString())
                .AppendLine(new string('-', 80))
                .ToString();
            File.AppendAllText(logPath, details, Encoding.UTF8);

            if (showDialog)
            {
                MessageBox.Show(
                    $"KOMBAIN Updater לא הצליח להיפתח.\n\n{exception.Message}\n\nיומן אבחון נשמר כאן:\n{logPath}",
                    "KOMBAIN Updater — שגיאת הפעלה",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
        catch
        {
            if (showDialog)
            {
                MessageBox.Show(exception.ToString(), "KOMBAIN Updater — שגיאת הפעלה", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
