namespace Kombain.Updater.Models;

public sealed record FleetRecord(string Serial, string AssetNumber, string DisplayName);
