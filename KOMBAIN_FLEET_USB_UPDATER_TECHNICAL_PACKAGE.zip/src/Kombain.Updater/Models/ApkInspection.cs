namespace Kombain.Updater.Models;

public sealed record ApkInspection(string Path, string Sha256, long SizeBytes, string PackageName, string VersionName, long VersionCode, string CertificateDigest, bool IsValid, string Message);
