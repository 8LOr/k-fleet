namespace Kombain.Updater.Models;

public sealed record DeploymentLogEntry(
    DateTimeOffset Timestamp,
    string DeploymentId,
    string Serial,
    string AssetNumber,
    string ApkFile,
    string VersionName,
    long VersionCode,
    string ApkSha256,
    string CertificateSha256,
    bool Simulation,
    string Result,
    string Message);
