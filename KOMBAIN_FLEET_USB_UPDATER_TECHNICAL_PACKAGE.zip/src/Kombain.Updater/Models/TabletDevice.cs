using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Kombain.Updater.Models;

public sealed class TabletDevice : INotifyPropertyChanged
{
    private bool _selected;
    private string _status = "ממתין לבדיקה";
    private int _progress;

    public bool Selected { get => _selected; set => Set(ref _selected, value); }
    public string Serial { get; init; } = "";
    public string AssetNumber { get; set; } = "לא משויך";
    public string DisplayName { get; set; } = "טאבלט לא מוכר";
    public string AdbState { get; init; } = "unknown";
    public string Model { get; set; } = "—";
    public string AndroidVersion { get; set; } = "—";
    public string AppVersion { get; set; } = "—";
    public string InstalledCertificateDigest { get; set; } = "";
    public int BatteryPercent { get; set; } = -1;
    public long FreeStorageMb { get; set; } = -1;
    public string Status { get => _status; set => Set(ref _status, value); }
    public int Progress { get => _progress; set => Set(ref _progress, value); }
    public string BatteryDisplay => BatteryPercent < 0 ? "—" : $"{BatteryPercent}%";
    public string StorageDisplay => FreeStorageMb < 0 ? "—" : $"{FreeStorageMb:N0} MB";
    public string CertificateDisplay => string.IsNullOrWhiteSpace(InstalledCertificateDigest) ? "לא זמין" : InstalledCertificateDigest[..Math.Min(12, InstalledCertificateDigest.Length)] + "…";

    public event PropertyChangedEventHandler? PropertyChanged;
    private void Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
