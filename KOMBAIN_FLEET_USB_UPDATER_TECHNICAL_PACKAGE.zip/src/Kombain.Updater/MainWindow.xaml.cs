using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Media;
using Kombain.Updater.Models;
using Kombain.Updater.Services;
using Microsoft.Win32;

namespace Kombain.Updater;

public partial class MainWindow : Window
{
    private readonly ProcessRunner _runner = new();
    private readonly ObservableCollection<TabletDevice> _devices = [];
    private readonly Dictionary<string, FleetRecord> _fleet = new(StringComparer.OrdinalIgnoreCase);
    private ApkInspection? _apk;
    private CancellationTokenSource? _deployment;

    public ObservableCollection<TabletDevice> Devices => _devices;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e)
    {
        SetBusy(true, "סורק את חיבורי ה־USB...");
        try
        {
            var discovered = await new AdbService(_runner).DiscoverAsync();
            _devices.Clear();
            foreach (var device in discovered)
            {
                ApplyFleetRecord(device);
                _devices.Add(device);
            }
            SummaryText.Text = $"זוהו {_devices.Count} טאבלטים • {_devices.Count(x => x.AdbState == "device")} מוכנים";
            MessageText.Text = _devices.Any(x => x.AdbState == "unauthorized") ? "יש לאשר את עמדת העדכונים בטאבלטים המסומנים כלא מורשים" : "הסריקה הושלמה";
        }
        catch (Exception ex) { ShowError(ex.Message); }
        finally { SetBusy(false); UpdateDeployState(); }
    }

    private void ImportFleet_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Title = "בחירת רשימת צי", Filter = "קובצי CSV (*.csv)|*.csv" };
        if (dialog.ShowDialog() != true) return;
        try
        {
            var csv = new FleetCsvService();
            var records = csv.Load(dialog.FileName);
            _fleet.Clear();
            foreach (var record in records) _fleet[record.Key] = record.Value;
            foreach (var device in _devices) ApplyFleetRecord(device);
            DevicesGrid.Items.Refresh();
            MessageText.Text = string.IsNullOrWhiteSpace(csv.Warning)
                ? $"נטענו {_fleet.Count} רשומות צי מקומיות • קידוד {csv.DetectedEncoding}"
                : $"נטענו {_fleet.Count} רשומות • {csv.Warning}";
        }
        catch (Exception ex) { ShowError(ex.Message); }
    }

    private async void ChooseApk_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog { Title = "בחירת גרסת KOMBAIN", Filter = "Android APK (*.apk)|*.apk" };
        if (dialog.ShowDialog() != true) return;
        SetBusy(true, "מאמת את חבילת העדכון...");
        try
        {
            _apk = await new ApkInspector(_runner).InspectAsync(dialog.FileName);
            ApkNameText.Text = Path.GetFileName(_apk.Path);
            ApkDetailsText.Text = $"גרסה {_apk.VersionName} ({_apk.VersionCode}) • {(_apk.SizeBytes / 1024d / 1024d):N1} MB • SHA-256 {_apk.Sha256[..16]}…";
            ApkStatusText.Text = _apk.Message;
            ApkStatusText.Foreground = (Brush)FindResource(_apk.IsValid ? "AccentBrightBrush" : "DangerBrush");
            SimulationToggle.IsEnabled = _apk.IsValid && _devices.Any(x => x.AdbState == "device");
        }
        catch (Exception ex) { _apk = null; ShowError(ex.Message); }
        finally { SetBusy(false); UpdateDeployState(); }
    }

    private void SelectAll_Click(object sender, RoutedEventArgs e) { foreach (var d in _devices.Where(x => x.AdbState == "device")) d.Selected = true; UpdateDeployState(); }
    private void ClearSelection_Click(object sender, RoutedEventArgs e) { foreach (var d in _devices) d.Selected = false; UpdateDeployState(); }

    private void SimulationToggle_Click(object sender, RoutedEventArgs e)
    {
        if (SimulationToggle.IsChecked == true)
        {
            MessageText.Text = "מצב סימולציה פעיל — לא יבוצע שינוי בטאבלטים";
            return;
        }

        MessageText.Text = "מצב פיילוט אמיתי — ניתן לעדכן טאבלט אחד בלבד ולא תתבצע הסרה של האפליקציה";
        var selected = _devices.Where(x => x.Selected && x.AdbState == "device").ToArray();
        if (selected.Length > 1)
        {
            foreach (var device in selected.Skip(1)) device.Selected = false;
            DevicesGrid.Items.Refresh();
            MessageBox.Show("בשלב הפיילוט נשאר מסומן טאבלט אחד בלבד. לאחר אימות מוצלח נפתח פריסה מדורגת למספר מכשירים.", "מצב פיילוט", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        UpdateDeployState();
    }

    private async void Deploy_Click(object sender, RoutedEventArgs e)
    {
        var targets = _devices.Where(x => x.Selected && x.AdbState == "device").ToArray();
        if (_apk is not { IsValid: true } || targets.Length == 0) return;
        var simulation = SimulationToggle.IsChecked == true;
        if (!simulation && targets.Length != 1)
        {
            ShowError("בשלב הפיילוט ניתן לבצע התקנה אמיתית על טאבלט אחד בלבד");
            return;
        }
        var deploymentId = $"DEP-{DateTimeOffset.Now:yyyyMMdd-HHmmss}";
        var prompt = simulation
            ? $"להריץ סימולציית עדכון על {targets.Length} טאבלטים? לא תתבצע התקנה."
            : $"להתקין את KOMBAIN גרסה {_apk.VersionName} ({_apk.VersionCode}) על טאבלט {targets[0].AssetNumber} / {targets[0].Serial}?\n\nהכלי יבצע עדכון בלבד, ללא הסרת האפליקציה.";
        if (MessageBox.Show(prompt, simulation ? "אישור סימולציה" : "אישור עדכון פיילוט", MessageBoxButton.YesNo, simulation ? MessageBoxImage.Information : MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        if (!simulation && MessageBox.Show("זהו עדכון אמיתי. ודא שאין בטאבלט טיוטה יחידה שלא גובתה. להמשיך כעת?", "אישור סופי", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

        _deployment = new CancellationTokenSource();
        SetBusy(true, simulation ? "מריץ סימולציה..." : "הפריסה מתבצעת...");
        var limiter = new SemaphoreSlim(6);
        try
        {
            await Task.WhenAll(targets.Select(device => DeployOne(device, _apk, deploymentId, simulation, limiter, _deployment.Token)));
            var succeeded = targets.Count(x => x.Status.Contains("הצלחה"));
            SummaryText.Text = $"הפריסה הסתיימה • {succeeded} הצליחו • {targets.Length - succeeded} נכשלו";
            MessageText.Text = targets.Length == succeeded
                ? simulation ? "הסימולציה הושלמה ללא שינוי בטאבלטים" : "עדכון הפיילוט הותקן והגרסה אומתה — יש לפתוח את KOMBAIN ולוודא שהנתונים נשמרו"
                : "אפשר לתקן את החיבור ולנסות שוב רק במכשירים שנכשלו";
        }
        catch (OperationCanceledException) { MessageText.Text = "הפריסה בוטלה"; }
        finally { SetBusy(false); UpdateDeployState(); _deployment.Dispose(); _deployment = null; }
    }

    private async Task DeployOne(TabletDevice device, ApkInspection apk, string deploymentId, bool simulation, SemaphoreSlim limiter, CancellationToken token)
    {
        await limiter.WaitAsync(token);
        var resultName = "failed";
        var resultMessage = "הפעולה לא הושלמה";
        try
        {
            device.Progress = 10; device.Status = "בודק מכשיר";
            await Task.Delay(simulation ? Random.Shared.Next(250, 700) : 150, token);
            if (device.BatteryPercent is >= 0 and < 20) { resultMessage = "סוללה נמוכה"; device.Status = $"נכשל: {resultMessage}"; device.Progress = 0; return; }
            if (!simulation)
            {
                device.Status = "משווה חתימה לגרסה המותקנת";
                device.InstalledCertificateDigest = await new AdbService(_runner).ReadInstalledCertificateDigestAsync(device, token);
                if (string.IsNullOrWhiteSpace(device.InstalledCertificateDigest))
                { resultMessage = "לא ניתן לאמת את חתימת הגרסה המותקנת"; device.Status = $"נכשל: {resultMessage}"; device.Progress = 0; return; }
                if (!string.Equals(device.InstalledCertificateDigest, apk.CertificateDigest, StringComparison.OrdinalIgnoreCase))
                { resultMessage = "חתימת ה־APK אינה תואמת לגרסה המותקנת"; device.Status = $"נכשל: {resultMessage}"; device.Progress = 0; return; }
            }
            device.Progress = 30; device.Status = simulation ? "מדמה העברת APK" : "מעביר ומתקין APK";
            if (simulation)
            {
                await Task.Delay(Random.Shared.Next(800, 1800), token);
            }
            else
            {
                var result = await new AdbService(_runner).InstallUpdateAsync(device, apk.Path, token);
                if (result.ExitCode != 0 || !result.Output.Contains("Success", StringComparison.OrdinalIgnoreCase))
                { resultMessage = FriendlyAdbError(result.Error + result.Output); device.Status = $"נכשל: {resultMessage}"; device.Progress = 0; return; }
            }
            device.Progress = 85; device.Status = "מאמת גרסה מותקנת";
            if (simulation) await Task.Delay(500, token);
            else
            {
                var installed = await new AdbService(_runner).ReadInstalledVersionAsync(device, token);
                if (installed.VersionCode != apk.VersionCode)
                { resultMessage = $"אימות הגרסה נכשל: נמצאה גרסה {installed.VersionCode}"; device.Status = $"נכשל: {resultMessage}"; device.Progress = 0; return; }
                device.AppVersion = installed.VersionName;
            }
            device.Progress = 100; device.Status = simulation ? "הצלחה — סימולציה" : "הצלחה — העדכון הותקן";
            resultName = "success";
            resultMessage = device.Status;
        }
        catch (Exception ex) { resultMessage = ex.Message; device.Status = $"נכשל: {resultMessage}"; device.Progress = 0; }
        finally
        {
            try
            {
                await new AuditLogService().AppendAsync(new DeploymentLogEntry(
                    DateTimeOffset.Now, deploymentId, device.Serial, device.AssetNumber, Path.GetFileName(apk.Path),
                    apk.VersionName, apk.VersionCode, apk.Sha256, apk.CertificateDigest, simulation, resultName, resultMessage), CancellationToken.None);
            }
            finally { limiter.Release(); }
        }
    }

    private void ApplyFleetRecord(TabletDevice device)
    {
        if (!_fleet.TryGetValue(device.Serial, out var record)) return;
        device.AssetNumber = record.AssetNumber;
        device.DisplayName = record.DisplayName;
    }

    private void UpdateDeployState()
    {
        var hasDevices = _devices.Any(x => x.Selected && x.AdbState == "device");
        DeployButton.IsEnabled = _apk is { IsValid: true } && hasDevices;
        SimulationToggle.IsEnabled = _apk is { IsValid: true } && hasDevices;
    }
    private void SetBusy(bool busy, string? message = null) { RefreshButton.IsEnabled = !busy; DeployButton.IsEnabled = !busy && DeployButton.IsEnabled; if (message is not null) MessageText.Text = message; }
    private void ShowError(string message) { MessageText.Text = message; MessageBox.Show(message, "KOMBAIN Updater", MessageBoxButton.OK, MessageBoxImage.Error); }
    private static string FriendlyAdbError(string text)
    {
        if (text.Contains("INSTALL_FAILED_UPDATE_INCOMPATIBLE")) return "חתימת ה־APK אינה תואמת לגרסה המותקנת";
        if (text.Contains("INSTALL_FAILED_VERSION_DOWNGRADE")) return "הגרסה שנבחרה ישנה מהגרסה המותקנת";
        if (text.Contains("INSTALL_FAILED_INSUFFICIENT_STORAGE")) return "אין מספיק מקום פנוי";
        if (text.Contains("device unauthorized")) return "יש לאשר את עמדת העדכונים בטאבלט";
        if (text.Contains("device offline")) return "הטאבלט נותק או אינו זמין";
        return string.IsNullOrWhiteSpace(text) ? "שגיאת התקנה לא ידועה" : text.Trim();
    }
}
